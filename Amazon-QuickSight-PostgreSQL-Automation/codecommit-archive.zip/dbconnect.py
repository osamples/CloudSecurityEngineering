import psycopg2
import os
import boto3
import json
import base64
import botocore
from botocore.exceptions import ClientError

# Import Boto3 Clients
sts = boto3.client('sts')
s3 = boto3.client('s3')
quicksight = boto3.client('quicksight')
secretsmanager = boto3.client('secretsmanager')

# Set Global Variables and Lists
awsRegion = os.environ['AWS_REGION']
awsAccountId = sts.get_caller_identity()['Account']
secretValue = os.environ['MY_SECRET']
hostName = os.environ['DB_ENDPOINT']
portNumber = 5432
dbName = os.environ['DB_NAME']
fileName = os.environ['S3_FILENAME']
groupName = os.environ['QUICKSIGHT_GROUP_NAME']
reportBucket = os.environ['QUICKSIGHT_DATASOURCE_BUCKET']
dataSourceName = os.environ['QUICKSIGHT_DATASOURCE_NAME']
vpcConnectionArn = os.environ['VPC_CONNECTION_ARN']

#Get User and Password
response = secretsmanager.get_secret_value(SecretId=secretValue)
dbSecret = json.loads(response['SecretString'])

dbUser = str(dbSecret['username'])
dbPw = str(dbSecret['password'])

#Load in file from S3 Bucket as 'file.json'
try:
    save_as = './file.json'
    s3.download_file(reportBucket, fileName, save_as)
    
except Exception as e:
    print(e)
    raise

#Connect to and load data into DB
def connect_load_data():
    try:
        connection = psycopg2.connect(user=dbUser,password=dbPw,host=hostName,port=portNumber,database=dbName)
    
        cursor = connection.cursor()
     # Print PostgreSQL Connection properties
        print ( connection.get_dsn_parameters(),"\n")
    
    # Print PostgreSQL version
        cursor.execute("SELECT version();")
        record = cursor.fetchone()
        print("You are connected to - ", record,"\n")
        
    ########### https://kb.objectrocket.com/postgresql/insert-json-data-into-postgresql-using-python-part-2-1248
        import json,sys
        from psycopg2 import connect, Error
        with open(save_as) as json_data:
            record_list = json.load(json_data)
            
        if type(record_list) == list:
            columns = [list(x.keys()) for x in record_list][0]
            print('\ncolumn names:', columns)
            table_name = "json_data_2"
            sql_string = 'INSERT INTO {} '.format( table_name )
            sql_string += "(" + ', '.join(columns) + ")\nVALUES "
            
            #This creates a table with all VARCHAR datatypes.
            create_table = 'CREATE TABLE {} '.format( table_name )
            create_table += "(" + ' VARCHAR, '.join(columns) + " VARCHAR );"
            
            #Use the below line to create a table with specific datatypes for your respective columns.
            #create_table = 'CREATE TABLE {} '.format( table_name) + '(AwsAccountId VARCHAR, AwsRegion VARCHAR, InstanceId VARCHAR, InstanceArn VARCHAR, FindingType VARCHAR, FindingTimestamp TIMESTAMP, RemoteIpv4Address VARCHAR, RemotePortNumber Integer, RemotePortName VARCHAR, LocalPortNumber Integer, LocalPortName VARCHAR, IpProtocol VARCHAR, Longitude NUMERIC, Latitude NUMERIC);'
        
       # enumerate over the record
        for i, record_dict in enumerate(record_list):
        
            # iterate over the values of each record dict object
            values = []
            for col_names, val in record_dict.items():
        
                # Postgres strings must be enclosed with single quotes
                if type(val) == str:
                    # escape apostrophies with two single quotations
                    val = val.replace("'", "''")
                    val = "'" + val + "'"
        
                values += [ str(val) ]
                
                    # join the list of values and enclose record in parenthesis
            sql_string += "(" + ', '.join(values) + "),\n"
        
        # remove the last comma and end statement with a semicolon
        sql_string = sql_string[:-2] + ";"
    
        # only attempt to execute SQL if cursor is valid
        if cursor != None:
        
            try:
                cursor.execute(create_table)
                cursor.execute( sql_string )
                connection.commit()
        
                print ('\nfinished INSERT INTO execution')
        
            except (Exception, Error) as error:
                print("\nexecute_sql() error:", error)
                connection.rollback()
        
            # close the cursor and connection
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")
    ##################
    
    except (Exception, psycopg2.Error) as error :
        print ("Error while connecting to PostgreSQL", error)
        raise error

def create_quicksight_group():
    try:
        response = quicksight.create_group(
            GroupName=groupName,
            Description='Dynamically created Group that contains all QuickSight Users currently onboarded',
            AwsAccountId=awsAccountId,
            Namespace='default' # this MUST be 'default'
        )
        groupPrincipalArn = str(response['Group']['Arn'])
        print(groupName + ' was created succesfully')
        print(groupName + ' ARN is ' + groupPrincipalArn)
    except botocore.exceptions.ClientError as error:
        # If the Group exists already, handle the error gracefull
        if error.response['Error']['Code'] == 'ResourceExistsException':
            response = quicksight.describe_group(
                GroupName=groupName,
                AwsAccountId=awsAccountId,
                Namespace='default' # this MUST be 'default'
            )
            groupArn = str(response['Group']['Arn'])
            print('A Group with the name ' + groupName + ' already exists! Attempting to add Users into it')
            print('As a reminder the ARN for ' + groupName + ' is: ' + groupArn)
        else:
            raise error
    
    try:
        response = quicksight.list_users(
            AwsAccountId=awsAccountId,
            MaxResults=100,
            Namespace='default' # this MUST be 'default'
        )
        for u in response['UserList']:
            userName = str(u['UserName'])
            roleLevel = str(u['Role'])
            if roleLevel == 'ADMIN' or 'AUTHOR':
                quicksight.create_group_membership(
                    MemberName=userName,
                    GroupName=groupName,
                    AwsAccountId=awsAccountId,
                    Namespace='default' # this MUST be 'default'
                )
                print('User ' + userName + ' added to Group ' + groupName)
            else:
                pass
    except Exception as e:
        print(e)

def create_quicksight_datasource():
    try:
        quicksight.create_data_source(
            AwsAccountId=awsAccountId,
            DataSourceId=dataSourceName,
            Name=dataSourceName,
            Type='AURORA_POSTGRESQL',
            VpcConnectionProperties={
                'VpcConnectionArn': vpcConnectionArn
            },
            Permissions=[
                {
                    'Principal': 'arn:aws:quicksight:' + awsRegion + ':' + awsAccountId + ':group/default/' + groupName,
                    'Actions': [
                        'quicksight:DescribeDataSource',
                        'quicksight:DescribeDataSourcePermissions',
                        'quicksight:PassDataSource',
                        'quicksight:UpdateDataSource',
                        'quicksight:DeleteDataSource',
                        'quicksight:UpdateDataSourcePermissions'
                    ]
                }
            ],
            DataSourceParameters={
                'AuroraPostgreSqlParameters': {
                    'Host': hostName,
                    'Port': portNumber,
                    'Database': dbName
                } 
            },
            Credentials={
                'CredentialPair': {
                    'Username': dbUser,
                    'Password': dbPw,
                }
            }
        )
        print('Data Source ' + dataSourceName + ' was created')
    except botocore.exceptions.ClientError as error:
        # If the Group exists already, handle the error gracefull
        if error.response['Error']['Code'] == 'ResourceExistsException':
            print('The Data Source ' + dataSourceName + ' already exists, attempting to update it')
            quicksight.update_data_source(
                AwsAccountId=awsAccountId,
                DataSourceId=dataSourceName,
                Name=dataSourceName,
                VpcConnectionProperties={
                    'VpcConnectionArn': vpcConnectionArn
                },
                DataSourceParameters={
                    'AuroraPostgreSqlParameters': {
                        'Host': hostName,
                        'Port': portNumber,
                        'Database': dbName
                    } 
                }
            )
            print('Data Source ' + dataSourceName + ' was updated')
        else:
            raise error
            
def main():
    connect_load_data()
    create_quicksight_group()
    create_quicksight_datasource()
    
main()